# Aeraris AI - Datos sinteticos de demo

Persona ficticia: Laura Martin, 34 anos.

Archivos:
- movimientos_julio.csv
- movimientos_agosto.csv
- movimientos_septiembre.csv
- factura_electricidad_agosto.pdf
- factura_electricidad_septiembre.pdf
- ticket_restaurante.pdf
- contexto_demo.json

Coherencia principal:
- Ingresos mensuales: 2.450 EUR.
- Gastos septiembre: 1.780 EUR.
- Ahorro septiembre: 670 EUR.
- Tasa de ahorro septiembre: 27,3 %.
- Restauracion septiembre: 214 EUR.
- Media restauracion julio-agosto: 182 EUR.
- Incremento: 17,6 %.
- Factura electrica agosto: 80,04 EUR / 234 kWh.
- Factura electrica septiembre: 91,24 EUR / 267 kWh.
- Incremento aproximado de consumo: 14,1 %.
- Fondo de emergencia de referencia: 4.950 EUR.
- Ahorro ya disponible: 2.000 EUR.
- Restante: 2.950 EUR.
- A 670 EUR/mes: aproximadamente 5 meses.

Todos los datos son ficticios y se han creado exclusivamente para una demostracion academica.
